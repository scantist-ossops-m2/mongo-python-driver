:mod:`max_key` -- Representation for the MongoDB internal MaxKey type
=====================================================================
.. versionadded:: 1.7

.. automodule:: bson.max_key
   :synopsis: Representation for the MongoDB internal MaxKey type
   :members:
