:mod:`uri_parser` -- Tools to parse and validate a MongoDB URI
==============================================================

.. automodule:: pymongo.uri_parser
   :synopsis: Tools to parse and validate a MongoDB URI.
   :members:
